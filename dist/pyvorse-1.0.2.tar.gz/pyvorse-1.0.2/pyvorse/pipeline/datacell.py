from pyvorse.core import basis, unibox

class dcell(unibox):
    """Stores data, and leads it inside pipeline.
    """